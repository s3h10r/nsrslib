::

  pip install https://github.com/s3h10r/nsrslib/dist/nsrslib-0.0.9.tar.gz --upgrade

