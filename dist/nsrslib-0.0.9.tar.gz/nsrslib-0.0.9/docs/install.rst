::

  pip install https://github.com/s3h10r/nsrslib/blob/develop/dist/nsrslib-0.0.9.tar.gz?raw=true --upgrade

