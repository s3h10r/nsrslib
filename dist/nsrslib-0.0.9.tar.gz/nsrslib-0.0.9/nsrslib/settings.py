# -*- coding: utf-8 -*-

NSR_SERVER = "localhost"

# nsr-bins linux
BIN_MMINFO="/usr/sbin/mminfo"
BIN_NSRADMIN="/usr/sbin/nsradmin"
# nsr-bins solaris 
#BIN_MMINFO="/opt/nsr/mminfo"
#BIN_NSRADMIN="/opt/nsr/nsradmin"
