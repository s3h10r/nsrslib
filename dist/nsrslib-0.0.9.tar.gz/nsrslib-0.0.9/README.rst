nsrslib - networker scripting library
=====================================

nsrslib tries to provide easy accees to basic networker-config-information
via python by wrapping networker-commands like `nsradmin` and `mminfo`.

it could be used directly on a networker server or on any host where the
networker client-software is installed.


usage
-----

please see `usage-example.py` or try::

    cd nsrslib && pydoc ./core.py

